# Converts all of our arrest data into a dataframe
arrest = spark.read.option("header",True).csv("clean_data.csv")
# Converts all of our affordable housing data into dataframe
afford = spark.read.option("header",True).csv("final_sum.csv")
#Gives us all of the unique precincts which we can iterate through
precincts = afford.select("POLICE_PRECINCT").distinct()
precinctCollect = precincts.collect()
# Go through the list
data_list = []
for i in precinctCollect:
    # Gets all of the units that have been built in that precinct
    units_built = afford.filter(afford.POLICE_PRECINCT == i["POLICE_PRECINCT"])
    # Gets affordable units built in that precinct
    affordable_units = int(units_built.agg({'AFFORDABLE_UNITS_SUM':'max'}).collect()[0][0])
    # This give us all of the crime with this 
    crime = arrest.filter(arrest.ARREST_PRECINCT == i["POLICE_PRECINCT"]) 
    average_crime = int(crime.agg({'count': 'avg'}).collect()[0][0])
    # We then append these to our arrays
    xy = [affordable_units, average_crime]
    data_list.append(xy)
df = sc.parallelize(data_list).toDF(['X','Y'])
# We then will print out the correlation using the data frame. 
df.stat.corr("X","Y")

